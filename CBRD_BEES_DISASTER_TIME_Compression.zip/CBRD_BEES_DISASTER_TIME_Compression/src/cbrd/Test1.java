/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cbrd;
import java.util.Vector;
import java.io.File;
import java.io.FileInputStream;
/**
 *
 * @author admin
 */
public class Test1 
{
    public static void main(String ar[])
    {
        try
        {
           /* String in1="jpegdecoder\\img3.jpeg";
            String out1="sift\\img3.jpeg";
                
            SIFT sif1=new SIFT();
            Vector<Feature> ft1=sif1.run1(in1, out1);
            
            String in2="jpegdecoder\\img1.jpeg";
            String out2="sift\\img1.jpeg";
                
            SIFT sif2=new SIFT();
            Vector<Feature> ft2=sif2.run1(in2, out2);
            
            System.out.println(ft1.size()+" : "+ft2.size());
            int t1=0;
            
            for(Feature f:ft1)
            {
                int r1=f.compareTo(ft2.elementAt(t1));
                
                
                float v1=f.descriptorDistance(ft2.elementAt(t1));
                
                
                System.out.println("d == "+r1+" : "+v1);
                t1++;
                
            }*/
            
           File f1=new File("in2");
           File f2=new File("arencode");
           
           File lt1[]=f1.listFiles();
           File lt2[]=f2.listFiles();
           double avg=0;
           for(int i=0;i<lt1.length;i++)
           {
               FileInputStream fi1=new FileInputStream(lt1[i]);
               FileInputStream fi2=new FileInputStream(lt2[i]);
               
               int l1=fi1.available();
               int l2=fi2.available();
               //long l1=lt1[i].length();
               //long l2=lt2[i].length();
               
               //long v1=l2/l1;
               double v1=(double)l2/(double)l1;
               double v2=(1-v1)*100;
               avg=avg+v2;
               System.out.println(11+" : "+l2+" : "+v1+" : "+v2);
           }
            
           System.out.println((avg/(double)lt1.length));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
