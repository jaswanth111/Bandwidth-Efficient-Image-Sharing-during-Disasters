/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cbrd;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
/**
 *
 * @author admin
 */
public class ArithmeticDecoding 
{
    
    public void decoding(File in1,File out1)
    {
        try
        {
            BitInputStream in = new BitInputStream(new BufferedInputStream(new FileInputStream(in1)));
            OutputStream out = new BufferedOutputStream(new FileOutputStream(out1));
            FrequencyTable freq = readFrequencies(in);
            decompress(freq, in, out);
            out.close();
            in.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    static FrequencyTable readFrequencies(BitInputStream in) throws IOException {
		int[] freqs = new int[257];
		for (int i = 0; i < 256; i++)
			freqs[i] = readInt(in, 32);
		freqs[256] = 1;  // EOF symbol
		return new SimpleFrequencyTable(freqs);
	}
	
	
	static void decompress(FrequencyTable freq, BitInputStream in, OutputStream out) throws IOException {
		ArithmeticDecoder dec = new ArithmeticDecoder(in);
		while (true) {
			int symbol = dec.read(freq);
			if (symbol == 256)  // EOF symbol
				break;
			out.write(symbol);
		}
	}
	
	
	private static int readInt(BitInputStream in, int numBits) throws IOException {
		if (numBits < 0 || numBits > 32)
			throw new IllegalArgumentException();
		
		int result = 0;
		for (int i = 0; i < numBits; i++)
			result |= in.readNoEof() << i;  // Little endian
		return result;
	}
	
}
