package cbrd;

public abstract class Node {
	
	Node() {}  // Package-private to prevent accidental subclassing outside of this package
	
}
