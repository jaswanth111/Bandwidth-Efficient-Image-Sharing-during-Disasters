/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cbrd;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
/**
 *
 * @author admin
 */
public class ArithmeticEncoding 
{
    public void encoding(File in1,File out1)
    {
        try
        {
            FrequencyTable freq = getFrequencies(in1);
            freq.increment(256);  
		
		
            InputStream in = new BufferedInputStream(new FileInputStream(in1));
            BitOutputStream out = new BitOutputStream(new BufferedOutputStream(new FileOutputStream(out1))); 
            
            writeFrequencies(out, freq);
            compress(freq, in, out);
            out.close();
            in.close();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    private static FrequencyTable getFrequencies(File file) throws IOException {
		FrequencyTable freq = new SimpleFrequencyTable(new int[257]);
		InputStream input = new BufferedInputStream(new FileInputStream(file));
		try {
			while (true) {
				int b = input.read();
				if (b == -1)
					break;
				freq.increment(b);
			}
		} finally {
			input.close();
		}
		return freq;
	}
	
	
	static void writeFrequencies(BitOutputStream out, FrequencyTable freq) throws IOException {
		for (int i = 0; i < 256; i++)
			writeInt(out, 32, freq.get(i));
	}
	
	
	static void compress(FrequencyTable freq, InputStream in, BitOutputStream out) throws IOException {
		ArithmeticEncoder enc = new ArithmeticEncoder(out);
		while (true) {
			int b = in.read();
			if (b == -1)
				break;
			enc.write(freq, b);
		}
		enc.write(freq, 256);  // EOF
		enc.finish();
	}
	
	
	private static void writeInt(BitOutputStream out, int numBits, int value) throws IOException {
		if (numBits < 0 || numBits > 32)
			throw new IllegalArgumentException();
		
		for (int i = 0; i < numBits; i++)
			out.write(value >>> i & 1);  // Little endian
	}
	
}
