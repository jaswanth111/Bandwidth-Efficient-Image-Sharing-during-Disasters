/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cbrd;
import java.util.ArrayList;
import java.util.Stack;
/**
 *
 * @author admin
 */
public class DFS 
{
    Details dt=new Details();
    static ArrayList<Nodes> dfsnodes=new ArrayList<Nodes>();
    Nodes nd[];
    ArrayList no1=new ArrayList();
    DFS(ArrayList node,int adj[][])
    {
        
        nd=new Nodes[node.size()];
        no1=node;
        for(int i=0;i<node.size();i++)
        {
            
            nd[i]=new Nodes(i);
            dfsnodes.add(nd[i]);
        }
       
        //clearVisitedFlags();
        //System.out.println();
        dfsUsingStack(adj, nd[0]);
        System.out.println();
    }
    
    static class Nodes 
    {
	int data;
	boolean visited;
	Nodes(int data) 
	{
            this.data=data;
	} 
    } 
    public ArrayList<Nodes> findNeighbours(int adjacency_matrix[][],Nodes x) 
	{
		int nodeIndex=-1;
		ArrayList<Nodes> neighbours=new ArrayList<Nodes>();
		for (int i = 0; i < dfsnodes.size(); i++) 
		{
			if(dfsnodes.get(i).equals(x)) 
			{
				nodeIndex=i;
				break;
			}
		} 
		if(nodeIndex!=-1) 
		{
			for (int j = 0; j < adjacency_matrix[nodeIndex].length; j++) 
			{
				if(adjacency_matrix[nodeIndex][j]==1) 
				{
					neighbours.add(dfsnodes.get(j));
				}
			} 
		} 
		return neighbours;
	}
        public static void clearVisitedFlags() 
	{
		for (int i = 0; i < dfsnodes.size(); i++) 
		{ 
			dfsnodes.get(i).visited=false;
		}
	} 
    public void dfsUsingStack(int adjacency_matrix[][], Nodes node) 
	{
		Stack<Nodes> stack=new Stack<Nodes>();
		stack.add(node);
		node.visited=true;
		while (!stack.isEmpty()) 
		{
			Nodes element=stack.pop();
			//System.out.print(element.data + "\t");
                        //int ind1=dfsnodes.indexOf(String.valueOf(element.data));
                        dt.rdfs1.add(no1.get(element.data));
                        System.out.print(no1.get(element.data) + "\t");
                        
			ArrayList<Nodes> neighbours=findNeighbours(adjacency_matrix,element);
			for (int i = 0; i < neighbours.size(); i++) 
			{
				Nodes n=neighbours.get(i);
				if(n!=null && !n.visited) 
				{
					stack.add(n);
					n.visited=true;
				}
			}
		}
	} 
}
